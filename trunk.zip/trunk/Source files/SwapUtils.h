#include <LArray.h>
#include <LStaticText.h>
void	SwapTRec(LArray *myArr);
void	SwapWaves(LArray *myArr);
short	DoShowSwapMessage(LStr255 *mystring);
Float64 SwapIntelIEEEFloat64A(Float64 fixMe);
Float64 FloatFromString(LStr255 *instring);